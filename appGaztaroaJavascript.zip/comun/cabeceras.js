export const CABECERAS =
    [
    {
        id: 0,
        nombre: '40 años de historia!',
        imagen: 'imagenes/mendiak.png',
        destacado: true,
        descripcion: '40 años organizando salidas para conocer y disfrutar la montaña'
    }
    ];
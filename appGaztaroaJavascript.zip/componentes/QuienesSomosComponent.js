import React, {  Component } from 'react';
import { SafeAreaView,FlatList,ListItem } from "react-native-gesture-handler";
import { Card } from "@rneui/themed";
import { Text, View } from "react-native";
import { ACTIVIDADES } from '../comun/actividades';
import { QUIENESSOMOS } from '../comun/quienessomos';

//dos cards
function RenderItem(props) {
    const item = props.item;
    
        if (item != null) {
            return(
                <Card>
                    <Card.Title>{item.nombre}</Card.Title>
                    <Card.Divider/>
                    <Text style={{margin: 20}}>
                        {item.descripcion}
                    </Text>
                </Card>   
            );
        }
        else {
            return(<View></View>);
        }
}






class QuienesSomos extends Component {
    constructor(props) {
        super(props);
        this.state = {
            actividades: ACTIVIDADES,// Datos de actividades
            quienessomos: QUIENESSOMOS // Datos de quienes somos
        };
    }

    render() {

        const RenderList = ({item, index}) => {
            return (
                <ListItem
                key={index}
                bottomDivider>
                    <Avatar source={require('./imagenes/40Años.png')} />
                    <ListItem.Content>
                        <ListItem.Title>{item.nombre}</ListItem.Title>
                        <ListItem.Subtitle>{item.descripcion}</ListItem.Subtitle>
                    </ListItem.Content>
                </ListItem> 
            );
        };

        return (
            <SafeAreaView>
                <RenderItem item={this.state.quienessomos[0]} />
            </SafeAreaView>
        );
    }
}



export default QuienesSomos;